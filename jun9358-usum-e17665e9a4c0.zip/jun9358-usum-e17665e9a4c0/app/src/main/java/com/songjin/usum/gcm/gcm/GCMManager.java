package com.songjin.usum.gcm.gcm;

/**
 * Created by IronFactory on 2016. 5. 8..
 */
public class GCMManager {

    public static final String REGISTRATION_REDAY = "registrationReady";
    public static final String REGISTRATION_GENERATION = "registrationGeneration";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
