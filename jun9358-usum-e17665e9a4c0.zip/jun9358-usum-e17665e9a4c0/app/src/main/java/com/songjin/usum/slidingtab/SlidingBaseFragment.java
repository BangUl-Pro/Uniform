package com.songjin.usum.slidingtab;

import android.support.v4.app.Fragment;

public abstract class SlidingBaseFragment extends Fragment {
    public abstract void onPageSelected();
}
